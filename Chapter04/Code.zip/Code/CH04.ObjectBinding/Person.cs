﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04.ObjectBinding
{
    public class Person
    {
        public string Name { get; set; }
        public string Blog { get; set; }
        public int Experience { get; set; }
    }
}
