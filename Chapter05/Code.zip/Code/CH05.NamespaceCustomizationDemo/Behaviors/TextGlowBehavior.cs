﻿using System.Windows.Controls;

namespace CH05.NamespaceCustomizationDemo.Behaviors
{
    public class TextGlowBehavior : Behavior<Label>
    {
    }
}
