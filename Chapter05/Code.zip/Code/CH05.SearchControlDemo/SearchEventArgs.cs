﻿using System;

namespace CH05.SearchControlDemo
{
    public class SearchEventArgs : EventArgs
    {
        public string SearchTerm { get; set; }
    }
}
